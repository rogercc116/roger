package com.fy.demo;
/**
 * 注释类
 * @author Roger
 * @date   2020年4月10日
 */
public class demo1 {
/**
 * 
 * main方法在一个class文件中只能出现一次
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Roger");//输出信息 单行注释
		System.out.println("男");
		System.out.println("18");
	}

}
