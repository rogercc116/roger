package com.fy.demo;
/**
 * 定义之前代码
 * @author Roger
 * @date   2020年4月10日
 */
public class demo3 {
	
	public static void main(String[] args) {
	String username="Roger";
	int age=18;
	double slary =6888;
	String address="江苏";
	char sex='男';
	System.out.println("我的姓名是"+username);
	System.out.println("我的年龄是"+age);
	System.out.println("我的月薪是"+slary);
	System.out.println("我的地址在"+address);
	System.out.println("我的性别是"+sex);
}
}
